﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Random random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        // Пузырьковая сортировка
        private void BubbleSort(DataGridView dataGridView, int columnIndex)
        {
            int n = dataGridView.Rows.Count;

            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {

                    int value1 = Convert.ToInt32(dataGridView.Rows[j].Cells[columnIndex].Value);
                    int value2 = Convert.ToInt32(dataGridView.Rows[j + 1].Cells[columnIndex].Value);

                    if (value1 > value2)
                    {

                        for (int k = 0; k < dataGridView.Columns.Count; k++)
                        {
                            object temp = dataGridView.Rows[j].Cells[k].Value;
                            dataGridView.Rows[j].Cells[k].Value = dataGridView.Rows[j + 1].Cells[k].Value;
                            dataGridView.Rows[j + 1].Cells[k].Value = temp;
                        }
                    }
                }
            }
        }

        // Сортировка вставками
        private void InsertionSort(DataGridView dataGridView, int columnIndex)
        {
            int n = dataGridView.Rows.Count;

            for (int i = 1; i < n; ++i)
            {
                int key = Convert.ToInt32(dataGridView.Rows[i].Cells[columnIndex].Value);
                int j = i - 1;


                while (j >= 0 && Convert.ToInt32(dataGridView.Rows[j].Cells[columnIndex].Value) > key)
                {
                    for (int k = 0; k < dataGridView.Columns.Count; k++)
                    {
                        object temp = dataGridView.Rows[j].Cells[k].Value;
                        dataGridView.Rows[j].Cells[k].Value = dataGridView.Rows[j + 1].Cells[k].Value;
                        dataGridView.Rows[j + 1].Cells[k].Value = temp;
                    }

                    j = j - 1;
                }

                dataGridView.Rows[j + 1].Cells[columnIndex].Value = key;
            }
        }

        // Расчет времени сортировки
        private long MeasureSortingTime(Action<DataGridView, int> sortingMethod, DataGridView dataGridView, int columnIndex)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            sortingMethod(dataGridView, columnIndex);

            stopwatch.Stop();
            return stopwatch.ElapsedMilliseconds;
        }

        // Шейкерная сортировка
        private void CocktailSort(DataGridView dataGridView, int columnIndex)
        {
            bool swapped;

            do
            {

                swapped = false;
                for (int i = 0; i <= dataGridView.Rows.Count - 2; i++)
                {
                    if (Convert.ToInt32(dataGridView.Rows[i].Cells[columnIndex].Value) > Convert.ToInt32(dataGridView.Rows[i + 1].Cells[columnIndex].Value))
                    {

                        for (int k = 0; k < dataGridView.Columns.Count; k++)
                        {
                            object temp = dataGridView.Rows[i].Cells[k].Value;
                            dataGridView.Rows[i].Cells[k].Value = dataGridView.Rows[i + 1].Cells[k].Value;
                            dataGridView.Rows[i + 1].Cells[k].Value = temp;
                        }

                        swapped = true;
                    }
                }

                if (!swapped)
                    break;


                swapped = false;
                for (int i = dataGridView.Rows.Count - 2; i >= 0; i--)
                {
                    if (Convert.ToInt32(dataGridView.Rows[i].Cells[columnIndex].Value) > Convert.ToInt32(dataGridView.Rows[i + 1].Cells[columnIndex].Value))
                    {

                        for (int k = 0; k < dataGridView.Columns.Count; k++)
                        {
                            object temp = dataGridView.Rows[i].Cells[k].Value;
                            dataGridView.Rows[i].Cells[k].Value = dataGridView.Rows[i + 1].Cells[k].Value;
                            dataGridView.Rows[i + 1].Cells[k].Value = temp;
                        }

                        swapped = true;
                    }
                }
            } while (swapped);
        }

        // Быстрая сортировка (Quicksort)
        private void QuickSort(DataGridView dataGridView, int columnIndex, int low, int high)
        {
            if (low < high)
            {
                int partitionIndex = Partition(dataGridView, columnIndex, low, high);

                QuickSort(dataGridView, columnIndex, low, partitionIndex - 1);
                QuickSort(dataGridView, columnIndex, partitionIndex + 1, high);
            }
        }

        private int Partition(DataGridView dataGridView, int columnIndex, int low, int high)
        {
            int pivot = Convert.ToInt32(dataGridView.Rows[high].Cells[columnIndex].Value);
            int i = (low - 1);

            for (int j = low; j < high; j++)
            {
                if (Convert.ToInt32(dataGridView.Rows[j].Cells[columnIndex].Value) < pivot)
                {
                    i++;


                    for (int k = 0; k < dataGridView.Columns.Count; k++)
                    {
                        object temp = dataGridView.Rows[i].Cells[k].Value;
                        dataGridView.Rows[i].Cells[k].Value = dataGridView.Rows[j].Cells[k].Value;
                        dataGridView.Rows[j].Cells[k].Value = temp;
                    }
                }
            }

            for (int k = 0; k < dataGridView.Columns.Count; k++)
            {
                object temp = dataGridView.Rows[i + 1].Cells[k].Value;
                dataGridView.Rows[i + 1].Cells[k].Value = dataGridView.Rows[high].Cells[k].Value;
                dataGridView.Rows[high].Cells[k].Value = temp;
            }

            return i + 1;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox2.Checked)
            {

                int columnIndex = 0;


                long sortingTime = MeasureSortingTime(InsertionSort, dataGridView1, columnIndex);
                label1.Text = $"Время сортировки: {sortingTime} мс";
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {


        }


        private long MeasureSortingTime(Action<DataGridView, int, int, int> sortingMethod, DataGridView dataGridView, int columnIndex)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            int low = 0;
            int high = dataGridView.Rows.Count - 1;

            sortingMethod(dataGridView, columnIndex, low, high);

            stopwatch.Stop();
            return stopwatch.ElapsedMilliseconds;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }



        private async void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                
            }
        }

        private async Task BogoSortAsync()
        {
            Random random = new Random();

            while (!IsSorted())
            {
                Shuffle();
            }
        }

        private void Shuffle()
        {
            int rowCount = dataGridView1.Rows.Count;

            for (int i = rowCount - 1; i > 0; i--)
            {
                int j = random.Next(0, i + 1);

                DataGridViewRow temp = (DataGridViewRow)dataGridView1.Rows[i].Clone();
                for (int k = 0; k < dataGridView1.Columns.Count; k++)
                {
                    temp.Cells[k].Value = dataGridView1.Rows[i].Cells[k].Value;
                    dataGridView1.Rows[i].Cells[k].Value = dataGridView1.Rows[j].Cells[k].Value;
                    dataGridView1.Rows[j].Cells[k].Value = temp.Cells[k].Value;
                }
            }
        }

        private bool IsSorted()
        {
            int rowCount = dataGridView1.Rows.Count;

            for (int i = 0; i < rowCount - 1; i++)
            {
                int currentValue = Convert.ToInt32(dataGridView1.Rows[i].Cells["Column1"].Value);
                int nextValue = Convert.ToInt32(dataGridView1.Rows[i + 1].Cells["Column1"].Value);

                if (currentValue > nextValue)
                {
                    return false;
                }
            }

            return true;
        }

        private async void рассчитатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                int columnIndex = 0;


                long sortingTime = MeasureSortingTime(BubbleSort, dataGridView1, columnIndex);
                label1.Text = $"Время сортировки: {sortingTime} мс";
            }

            if (checkBox2.Checked)
            {
                int columnIndex = 0;


                long sortingTime = MeasureSortingTime(InsertionSort, dataGridView1, columnIndex);
                label1.Text = $"Время сортировки: {sortingTime} мс";
            }

            if (checkBox3.Checked)
            {
                int columnIndex = 0;


                long sortingTime = MeasureSortingTime(CocktailSort, dataGridView1, columnIndex);
                label1.Text = $"Время сортировки: {sortingTime} мс";
            }

            if (checkBox4.Checked)
            {
                int columnIndex = 0;

                long sortingTime = MeasureSortingTime(QuickSort, dataGridView1, columnIndex);
                label1.Text = $"Время сортировки: {sortingTime} мс";
            }

            if (checkBox5.Checked)
            {
                await BogoSortAsync();
            }

        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
