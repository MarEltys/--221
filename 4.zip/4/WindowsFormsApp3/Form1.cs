﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using NCalc;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void рассчитатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string function = textBox1.Text;
            double A = Convert.ToDouble(textBox2.Text);
            double B = Convert.ToDouble(textBox3.Text);
            double precision = Convert.ToDouble(textBox4.Text);

            chart1.Series.Clear();

            Series rectangleSeries = new Series("Метод прямоугольников");
            Series trapezoidSeries = new Series("Метод трапеций");
            Series simpsonSeries = new Series("Метод Симпсона");

            if (checkBox1.Checked)
            {
                double resultRectangle = RectangleMethod(function, A, B, precision);
                AddDataPoints(rectangleSeries, resultRectangle);
            }

            if (checkBox2.Checked)
            {
                double resultTrapezoid = TrapezoidMethod(function, A, B, precision);
                AddDataPoints(trapezoidSeries, resultTrapezoid);
            }

            if (checkBox3.Checked)
            {
                double resultSimpson = SimpsonsMethod(function, A, B, precision);
                AddDataPoints(simpsonSeries, resultSimpson);
            }

            chart1.Series.Add(rectangleSeries);
            chart1.Series.Add(trapezoidSeries);
            chart1.Series.Add(simpsonSeries);
        }

        private void AddDataPoints(Series series, double result)
        {
            series.Points.AddXY("Результат", result);
        }

        private double RectangleMethod(string function, double A, double B, double precision)
        {
            int n = 1000; 
            double h = (B - A) / n;

            double result = 0;

            for (int i = 0; i < n; i++)
            {
                double x_midpoint = A + i * h + 0.5 * h;
                double y = EvaluateFunction(function, x_midpoint);
                result += y * h; 
            }

            return result;
        }

        private double EvaluateFunction(string function, double x)
        {
            Expression expression = new Expression(function);
            expression.Parameters["x"] = x;

            if (expression.HasErrors())
            {
                throw new InvalidOperationException("Ошибка в выражении функции");
            }

            return Convert.ToDouble(expression.Evaluate());
        }

        private double TrapezoidMethod(string function, double A, double B, double precision)
        {
            int n = 1000;
            double h = (B - A) / n;

            double result = 0;

            for (int i = 0; i < n; i++)
            {
                double x0 = A + i * h;
                double x1 = A + (i + 1) * h;

                double y0 = EvaluateFunction(function, x0);
                double y1 = EvaluateFunction(function, x1);

                result += 0.5 * (y0 + y1) * h;
            }

            return result;
        }

        private double SimpsonsMethod(string function, double A, double B, double precision)
        {
            int n = 1000; 
            if (n % 2 == 1) n++;

            double h = (B - A) / n;

            double result = 0;

            for (int i = 0; i < n; i += 2)
            {
                double x0 = A + i * h;
                double x1 = A + (i + 1) * h;
                double x2 = A + (i + 2) * h;

                double y0 = EvaluateFunction(function, x0);
                double y1 = EvaluateFunction(function, x1);
                double y2 = EvaluateFunction(function, x2);

                result += (h / 3) * (y0 + 4 * y1 + y2);
            }

            return result;
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
