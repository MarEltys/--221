﻿using System;
using System.Windows.Forms;
using NCalc;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBoxA.Text, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double a) &&
                double.TryParse(textBoxB.Text, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double b) &&
                double.TryParse(textBoxE.Text, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double tolerance))
            {
                string functionExpression = textBoxFunction.Text;

                double minimum = FindLocalMinimum(a, b, tolerance, functionExpression);

                MessageBox.Show($"Найденный минимум: {minimum}");

                UpdateChart(functionExpression, a, b);
            }
            else
            {
                MessageBox.Show("Ошибка в формате ввода числа.");
            }
        }

        private void UpdateChart(string functionExpression, double a, double b)
        {
            chartFunction.Series.Clear();

            Series series = chartFunction.Series.Add("Function");
            series.ChartType = SeriesChartType.Line;

            for (double x = a; x <= b; x += 0.1)
            {
                double y = EvaluateFunction(functionExpression, x);
                series.Points.AddXY(x, y);
            }
        }

        private double EvaluateFunction(string functionExpression, double x)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(functionExpression))
                {
                    MessageBox.Show("Ошибка: выражение функции не может быть пустым.");
                    return double.NaN;
                }

                Expression expression = new Expression(functionExpression, EvaluateOptions.IgnoreCase);
                expression.Parameters["x"] = x;

                double result = (double)expression.Evaluate();
                return result;
            }
            catch (EvaluationException ex)
            {
  
                MessageBox.Show($"Ошибка при выполнении функции: {ex.Message}");
                return double.NaN;
            }
        }



        private double FindLocalMinimum(double a, double b, double tolerance, string functionExpression)
        {
            Expression expression = new Expression("(1 + Sqrt(5)) / 2");
            double goldenRatio = (double)expression.Evaluate();

            double x1 = b - (b - a) / goldenRatio;
            double x2 = a + (b - a) / goldenRatio;

            while (Math.Abs(b - a) > tolerance)
            {
                double f1 = EvaluateFunction(functionExpression, x1);
                double f2 = EvaluateFunction(functionExpression, x2);

                if (f1 < f2)
                {
                    b = x2;
                    x2 = x1;
                    x1 = b - (b - a) / goldenRatio;
                }
                else
                {
                    a = x1;
                    x1 = x2;
                    x2 = a + (b - a) / goldenRatio;
                }
            }

            return (a + b) / 2;
        }


        private void button2_Click(object sender, EventArgs e)
        {
            textBoxA.Clear();
            textBoxB.Clear();
            textBoxE.Clear();
            textBoxFunction.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chartFunction.ChartAreas.Add(new ChartArea());
            chartFunction.Series.Add(new Series());

            chartFunction.ChartAreas[0].AxisX.Minimum = -10;
            chartFunction.ChartAreas[0].AxisX.Maximum = 10;

            for (double x = -10; x <= 10; x += 0.1)
            {
                double y = x * x;
                chartFunction.Series[0].Points.AddXY(x, y);
            }
        }

        private void рассчитатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBoxA.Text, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double a) &&
                double.TryParse(textBoxB.Text, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double b) &&
                double.TryParse(textBoxE.Text, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double tolerance))
            {
                string functionExpression = textBoxFunction.Text;


                double minimum = FindLocalMinimum(a, b, tolerance, functionExpression);


                textBoxOtvet.Text = $"Найденный минимум: {minimum}";

                UpdateChart(functionExpression, a, b);
            }
            else
            {
                MessageBox.Show("Ошибка в формате ввода числа.");
            }
        }

        private void очиститьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBoxA.Clear();
            textBoxB.Clear();
            textBoxE.Clear();
            textBoxFunction.Clear();
        }

        private void chartFunction_Click(object sender, EventArgs e)
        {

        }

        private void textBoxA_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
