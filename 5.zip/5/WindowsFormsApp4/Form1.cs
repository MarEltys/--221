﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async Task CalculateAsync()
        {
            Stopwatch stopwatch = new Stopwatch();
            double[] result;

            if (checkBox1.Checked)
            {
                // Реализация метода Гаусса
                SolveUsingGauss();
            }
            else if (checkBox2.Checked)
            {
                // Реализация метода квадратного корня
                SolveUsingCholeskyDecomposition();
            }
            else if (checkBox3.Checked)
            {
                // Реализация метода прогонки
                SolveUsingTridiagonalMatrixAlgorithm();
            }
            else if (checkBox4.Checked)
            {
                // Реализация метода простой итерации
                SolveUsingSimpleIteration();
            }
            else if (checkBox5.Checked)
            {
                // Реализация метода наискорейшего спуска
                SolveUsingGradientDescent();
            }
            else if (checkBox6.Checked)
            {
                // Реализация метода сопряженных градиентов
                SolveUsingConjugateGradient();
            }
            else
            {
                MessageBox.Show("Выберите метод решения!");
                return;
            }

            stopwatch.Start();

            await Task.Run(() =>
            {
                result = SolveEquation();

                Invoke(new Action(() =>
                {
                    for (int i = 0; i < result.Length; i++)
                    {
                        dataGridView1.Rows.Add(result[i]);
                    }
                    stopwatch.Stop();
                    textBox1.Text = $"Время выполнения: {stopwatch.ElapsedMilliseconds} мс";
                }));
            });
        }

        private void SolveUsingGauss()
        {
            int n = dataGridView1.RowCount;
            double[,] A = new double[n, n];
            double[] B = new double[n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    A[i, j] = Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value);
                }
                B[i] = Convert.ToDouble(dataGridView1.Rows[i].Cells[n].Value);
            }

            double[] result = SolveLinearSystemGauss(A, B);

            for (int i = 0; i < n; i++)
            {
                dataGridView1.Rows[i].Cells[n + 1].Value = result[i]; 
            }
        }

        private double[] SolveLinearSystemGauss(double[,] A, double[] B)
        {
            int n = A.GetLength(0);
            double[] result = new double[n];

            for (int k = 0; k < n - 1; k++)
            {
                for (int i = k + 1; i < n; i++)
                {
                    double factor = A[i, k] / A[k, k];
                    for (int j = k; j < n; j++)
                    {
                        A[i, j] -= factor * A[k, j];
                    }
                    B[i] -= factor * B[k];
                }
            }

            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0.0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += A[i, j] * result[j];
                }
                result[i] = (B[i] - sum) / A[i, i];
            }

            return result;
        }

        private void SolveUsingCholeskyDecomposition()
        {
            int n = dataGridView1.RowCount;
            double[,] A = new double[n, n];
            double[] B = new double[n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    A[i, j] = Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value);
                }
                B[i] = Convert.ToDouble(dataGridView1.Rows[i].Cells[n].Value);
            }

            double[] result = SolveLinearSystemCholesky(A, B);

            for (int i = 0; i < n; i++)
            {
                dataGridView1.Rows[i].Cells[n + 1].Value = result[i];
            }
        }

        private double[] SolveLinearSystemCholesky(double[,] A, double[] B)
        {
            int n = A.GetLength(0);
            double[,] L = new double[n, n]; 
            double[] Y = new double[n]; 
            double[] result = new double[n]; 

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    double sum = A[i, j];
                    for (int k = 0; k < j; k++)
                    {
                        sum -= L[i, k] * L[j, k];
                    }
                    if (i == j)
                    {
                        L[i, j] = Math.Sqrt(Math.Max(sum, 0));
                    }
                    else
                    {
                        L[i, j] = sum / L[j, j];
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                double sum = B[i];
                for (int j = 0; j < i; j++)
                {
                    sum -= L[i, j] * Y[j];
                }
                Y[i] = sum / L[i, i];
            }

            for (int i = n - 1; i >= 0; i--)
            {
                double sum = Y[i];
                for (int j = i + 1; j < n; j++)
                {
                    sum -= L[j, i] * result[j];
                }
                result[i] = sum / L[i, i];
            }

            return result;
        }


        private void SolveUsingTridiagonalMatrixAlgorithm()
        {
            int n = dataGridView1.RowCount;
            double[] A = new double[n]; 
            double[] B = new double[n - 1];
            double[] C = new double[n - 1]; 
            double[] D = new double[n];

            for (int i = 0; i < n; i++)
            {
                A[i] = Convert.ToDouble(dataGridView1.Rows[i].Cells[i].Value);
                D[i] = Convert.ToDouble(dataGridView1.Rows[i].Cells[n].Value);
            }


            for (int i = 0; i < n - 1; i++)
            {
                B[i] = Convert.ToDouble(dataGridView1.Rows[i].Cells[i + 1].Value);
                C[i] = Convert.ToDouble(dataGridView1.Rows[i + 1].Cells[i].Value);
            }

            double[] result = SolveLinearSystemTridiagonal(A, B, C, D);

            for (int i = 0; i < n; i++)
            {
                dataGridView1.Rows[i].Cells[n + 1].Value = result[i]; 
            }
        }


        private double[] SolveLinearSystemTridiagonal(double[] A, double[] B, double[] C, double[] D)
        {
            int n = A.Length;
            double[] alpha = new double[n];
            double[] beta = new double[n];
            double[] result = new double[n];

            alpha[0] = A[0];
            beta[0] = D[0] / alpha[0];

            for (int i = 1; i < n; i++)
            {
                alpha[i] = A[i] - B[i - 1] * C[i - 1] / alpha[i - 1];
                beta[i] = (D[i] - B[i - 1] * beta[i - 1]) / alpha[i];
            }

            result[n - 1] = beta[n - 1];

            for (int i = n - 2; i >= 0; i--)
            {
                result[i] = beta[i] - C[i] * result[i + 1] / alpha[i];
            }

            return result;
        }

        private void SolveUsingSimpleIteration()
        {
            int n = dataGridView1.RowCount;
            double[,] A = new double[n, n];
            double[] B = new double[n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    A[i, j] = Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value);
                }
                B[i] = Convert.ToDouble(dataGridView1.Rows[i].Cells[n].Value);
            }

            double[] result = SolveLinearSystemSimpleIteration(A, B);

            for (int i = 0; i < n; i++)
            {
                dataGridView1.Rows[i].Cells[n + 1].Value = result[i]; 
            }
        }

        private double[] SolveLinearSystemSimpleIteration(double[,] A, double[] B)
        {
            int n = A.GetLength(0);
            double[] result = new double[n];
            double[] previousResult = new double[n];
            double epsilon = 1e-9; 
            int maxIterations = 1000;

            for (int i = 0; i < n; i++)
            {
                result[i] = 0.0;
            }

            for (int iteration = 0; iteration < maxIterations; iteration++)
            {
                Array.Copy(result, previousResult, n);

                for (int i = 0; i < n; i++)
                {
                    double sum = 0.0;
                    for (int j = 0; j < n; j++)
                    {
                        if (i != j)
                        {
                            sum += A[i, j] * previousResult[j];
                        }
                    }
                    result[i] = (B[i] - sum) / A[i, i];
                }

                bool convergenceAchieved = true;
                for (int i = 0; i < n; i++)
                {
                    if (Math.Abs(result[i] - previousResult[i]) > epsilon)
                    {
                        convergenceAchieved = false;
                        break;
                    }
                }

                if (convergenceAchieved)
                {
                    break;
                }
            }

            return result;
        }

        private void SolveUsingGradientDescent()
        {
            int n = dataGridView1.RowCount;
            double[,] A = new double[n, n];
            double[] B = new double[n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    A[i, j] = Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value);
                }
                B[i] = Convert.ToDouble(dataGridView1.Rows[i].Cells[n].Value);
            }

            double[] result = SolveLinearSystemGradientDescent(A, B);

            for (int i = 0; i < n; i++)
            {
                dataGridView1.Rows[i].Cells[n + 1].Value = result[i]; 
            }
        }

        private double[] SolveLinearSystemGradientDescent(double[,] A, double[] B)
        {
            int n = A.GetLength(0);
            double[] result = new double[n];
            double[] gradient = new double[n];
            double epsilon = 1e-9; 
            int maxIterations = 1000; 
            double alpha = 0.01; 

            for (int i = 0; i < n; i++)
            {
                result[i] = 0.0;
            }

            for (int iteration = 0; iteration < maxIterations; iteration++)
            {

                ComputeGradient(A, B, result, gradient);

                for (int i = 0; i < n; i++)
                {
                    result[i] -= alpha * gradient[i];
                }

                double norm = ComputeNorm(gradient);
                if (norm < epsilon)
                {
                    break;
                }
            }

            return result;
        }

        private void ComputeGradient(double[,] A, double[] B, double[] X, double[] gradient)
        {
            int n = A.GetLength(0);

            for (int i = 0; i < n; i++)
            {
                gradient[i] = 0.0;
                for (int j = 0; j < n; j++)
                {
                    gradient[i] += A[i, j] * X[j];
                }
                gradient[i] -= B[i];
            }
        }

        private double ComputeNorm(double[] vector)
        {
            double sum = 0.0;

            foreach (var element in vector)
            {
                sum += element * element;
            }

            return Math.Sqrt(sum);
        }

        private void SolveUsingConjugateGradient()
        {
            int n = dataGridView1.RowCount;
            double[,] A = new double[n, n];
            double[] B = new double[n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    A[i, j] = Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value);
                }
                B[i] = Convert.ToDouble(dataGridView1.Rows[i].Cells[n].Value);
            }

            double[] result = SolveLinearSystemConjugateGradient(A, B);

            for (int i = 0; i < n; i++)
            {
                dataGridView1.Rows[i].Cells[n + 1].Value = result[i]; 
            }
        }

        private double[] SolveLinearSystemConjugateGradient(double[,] A, double[] B)
        {
            int n = A.GetLength(0);
            double[] result = new double[n];
            double[] gradient = new double[n];
            double[] direction = new double[n];
            double[] product = new double[n];
            double epsilon = 1e-9; 

            for (int i = 0; i < n; i++)
            {
                result[i] = 0.0;
            }

            ComputeGradient(A, B, result, gradient);

            for (int i = 0; i < n; i++)
            {
                direction[i] = -gradient[i];
            }

            for (int iteration = 0; iteration < n; iteration++)
            {
                MultiplyMatrixVector(A, direction, product);

                double alpha = ComputeAlpha(gradient, direction, product);

                for (int i = 0; i < n; i++)
                {
                    result[i] += alpha * direction[i];
                }

                for (int i = 0; i < n; i++)
                {
                    gradient[i] -= alpha * product[i];
                }

                double norm = ComputeNorm(gradient);
                if (norm < epsilon)
                {
                    break;
                }

                double beta = ComputeBeta(gradient, direction);

                for (int i = 0; i < n; i++)
                {
                    direction[i] = -gradient[i] + beta * direction[i];
                }
            }

            return result;
        }

        private void MultiplyMatrixVector(double[,] matrix, double[] vector, double[] result)
        {
            int n = matrix.GetLength(0);

            for (int i = 0; i < n; i++)
            {
                result[i] = 0.0;
                for (int j = 0; j < n; j++)
                {
                    result[i] += matrix[i, j] * vector[j];
                }
            }
        }

        private double ComputeAlpha(double[] gradient, double[] direction, double[] product)
        {
            double numerator = 0.0;
            double denominator = 0.0;
            int n = gradient.Length;

            for (int i = 0; i < n; i++)
            {
                numerator += gradient[i] * gradient[i];
                denominator += direction[i] * product[i];
            }

            return numerator / denominator;
        }

        private double ComputeBeta(double[] gradient, double[] direction)
        {
            double numerator = 0.0;
            double denominator = 0.0;
            int n = gradient.Length;

            for (int i = 0; i < n; i++)
            {
                numerator += gradient[i] * gradient[i];
                denominator += direction[i] * direction[i];
            }

            return numerator / denominator;
        }

        private double[] SolveEquation()
        {
            Random random = new Random();
            double[] result = new double[dataGridView1.RowCount];
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = random.NextDouble();
            }

            return result;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            int N;
            if (!int.TryParse(textBoxN.Text, out N) || N < 2 || N > 50)
            {
                MessageBox.Show("Введите корректное значение N (2 <= N <= 50).");
                return;
            }

            for (int i = 0; i < N; i++)
            {
                dataGridView1.Columns.Add($"ColumnA{i + 1}", $"A{i + 1}");
            }

            dataGridView1.Columns.Add("ColumnB", "B");

            Random random = new Random();
            double[,] A = new double[N, N];
            double[] B = new double[N];

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    A[i, j] = random.NextDouble();
                }
                B[i] = random.NextDouble();
            }

            for (int i = 0; i < N; i++)
            {
                DataGridViewRow row = new DataGridViewRow();

                for (int j = 0; j < N; j++)
                {
                    row.Cells.Add(new DataGridViewTextBoxCell { Value = A[i, j] });
                }

                row.Cells.Add(new DataGridViewTextBoxCell { Value = B[i] });
                dataGridView1.Rows.Add(row);
            }
        }


        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
        }

        private async void рассчитатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            textBox1.Clear();

            await CalculateAsync();
        }
    }
}
