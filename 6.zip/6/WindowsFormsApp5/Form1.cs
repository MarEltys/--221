﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeChart();
        }

        private void InitializeChart()
        {
            chart1.ChartAreas.Add(new ChartArea("Default"));
            Series series = new Series("DataPoints");
            series.ChartType = SeriesChartType.Point;
            chart1.Series.Add(series);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GenerateRandomData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private List<PointF> GetDataFromDataGridView()
        {
            List<PointF> dataPoints = new List<PointF>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells.Count == 2 &&
                    float.TryParse(row.Cells[0].Value?.ToString(), out float x) &&
                    float.TryParse(row.Cells[1].Value?.ToString(), out float y))
                {
                    dataPoints.Add(new PointF(x, y));
                }
            }

            return dataPoints;
        }

        private double[] CalculateCoefficients(List<PointF> dataPoints, int n)
        {
            var coefficients = new double[n + 1];
            var xPowers = Enumerable.Range(0, n + 1).Select(i => dataPoints.Select(p => Math.Pow(p.X, i)).ToArray()).ToArray();
            var yValues = dataPoints.Select(p => (double)p.Y).ToArray();

            for (int i = 0; i <= n; i++)
            {
                coefficients[i] = xPowers[i].Zip(yValues, (x, y) => x * y).Sum() / xPowers[i].Sum(x => x * x);
            }

            return coefficients;
        }

        private void DisplayDataOnChart(List<PointF> dataPoints)
        {
            chart1.Series["DataPoints"].Points.Clear();
            foreach (var point in dataPoints)
            {
                chart1.Series["DataPoints"].Points.AddXY(point.X, point.Y);
            }
        }

        private void GenerateRandomData()
        {
            Random random = new Random();

            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            dataGridView1.Columns.Add("ColumnX", "X");
            dataGridView1.Columns.Add("ColumnY", "Y");

            for (int i = 0; i < 10; i++)
            {
                float x = (float)random.NextDouble() * 10;
                float y = (float)random.NextDouble() * 10;
                dataGridView1.Rows.Add(x, y);
            }
        }

        private void рассчитатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                List<PointF> dataPoints = GetDataFromDataGridView();

                double[] coefficientsN1 = CalculateCoefficients(dataPoints, 1);

                double[] coefficientsN2 = CalculateCoefficients(dataPoints, 2);

                textBox1.Text = $"Коэффициенты для n = 1: {string.Join(", ", coefficientsN1)}\r\n" +
                                 $"Коэффициенты для n = 2: {string.Join(", ", coefficientsN2)}";

                DisplayDataOnChart(dataPoints);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при расчете: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void генерацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GenerateRandomData();
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }
    }
}
